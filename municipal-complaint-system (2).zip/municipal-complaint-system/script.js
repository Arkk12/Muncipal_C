// Global variables
// Note: Local state is removed. All operations now rely on fetching from the server.
let complaintCounter = parseInt(localStorage.getItem('complaintCounter')) || 1; // Kept only for legacy or if still used elsewhere.

// Admin authentication variables
const ADMIN_CREDENTIALS = {
    username: 'admin',
    password: 'admin123'
};
let isAdminLoggedIn = false;
let currentAdminUser = null;

// DOM elements
const navLinks = document.querySelectorAll('.nav-link');
const pages = document.querySelectorAll('.page');
const successModal = document.getElementById('successModal');
const closeModalBtn = document.querySelector('.close');

// --- Initialization ---

document.addEventListener('DOMContentLoaded', function() {
    initializeNavigation();
    initializeFormValidation();
    initializeModal();
    initializeAdminAuth();
    
    // REMOVE or comment out populateSampleData() to avoid old local storage logic
    // populateSampleData(); 
});


// --- Helper Functions ---

function showError(message) {
    alert("Error: " + message);
}

function showSuccess(message) {
    alert("Success: " + message);
}


// --- API Interaction Functions ---

// Function to fetch all complaints from the backend
async function fetchComplaints() {
    try {
        const res = await fetch("http://localhost:5000/complaints");
        if (!res.ok) {
            throw new Error("Failed to fetch data from server");
        }
        return await res.json();
    } catch (err) {
        console.error("❌ Failed to fetch complaints:", err);
        showError("Error loading complaints from server.");
        return [];
    }
}


// --- Admin Dashboard Functionality ---

// Renders the complaint data into the admin table
async function loadComplaintsTable(complaintsData) {
    const tableBody = document.getElementById('complaintsTableBody');
    if (!tableBody) return;

    // Fetch data if none is provided (used for initial load and after successful action)
    const data = complaintsData || await fetchComplaints();

    tableBody.innerHTML = "";

    if (data.length === 0) {
        tableBody.innerHTML = `
            <tr>
                <td colspan="7" style="text-align: center; padding: 2rem;">
                    <i class="fas fa-search" style="font-size: 2rem; color: #6b7280; margin-bottom: 1rem;"></i>
                    <p>No complaints found in database</p>
                </td>
            </tr>
        `;
        return;
    }

    data.forEach((complaint) => {
        const row = document.createElement("tr");
        const status = complaint.status ? complaint.status.toLowerCase() : 'pending';
        
        // We pass the complaintId to the action buttons
        const actionId = complaint.complaintId; 

        row.innerHTML = `
            <td>${complaint.complaintId || complaint._id}</td>
            <td>${complaint.fullName}</td>
            <td>${complaint.category}</td>
            <td><span class="status-badge status-${status.replace('-', '')}">${status.toUpperCase()}</span></td>
            <td>${complaint.assignedOfficer || "Not Assigned"}</td>
            <td>${complaint.date ? new Date(complaint.date).toLocaleDateString() : "N/A"}</td>
            <td>
                <button class="action-btn view" onclick="viewComplaint('${actionId}')">View</button>
                <button class="action-btn edit" onclick="editComplaint('${actionId}')">Edit</button>
                <button class="action-btn delete" onclick="deleteComplaint('${actionId}')">Delete</button>
            </td>
        `;
        tableBody.appendChild(row);
    });
}

// Function to filter complaints based on search and status
async function filterComplaints() {
    const searchTerm = document.getElementById('adminSearch').value.toLowerCase();
    const statusFilter = document.getElementById('statusFilter').value.toLowerCase();
    
    // 1. Fetch ALL complaints first
    const allComplaints = await fetchComplaints();

    // 2. Filter the array client-side
    const filteredComplaints = allComplaints.filter(complaint => {
        const id = complaint.complaintId ? complaint.complaintId.toLowerCase() : '';
        const name = complaint.fullName ? complaint.fullName.toLowerCase() : '';
        const category = complaint.category ? complaint.category.toLowerCase() : '';
        const status = complaint.status ? complaint.status.toLowerCase() : '';

        const matchesSearch = name.includes(searchTerm) ||
                             id.includes(searchTerm) ||
                             category.includes(searchTerm);
        
        const matchesStatus = !statusFilter || statusFilter === 'all' || status === statusFilter;
        
        return matchesSearch && matchesStatus;
    });
    
    // 3. Display the filtered list
    loadComplaintsTable(filteredComplaints);
}

// View complaint function (fetches the data)
/*async function viewComplaint(complaintId) {
    try {
        const res = await fetch(`http://localhost:5000/complaints/${complaintId}`);
        const complaint = await res.json();

        if (res.ok && complaint && complaint.complaintId) {
            alert(`Complaint Details:\n\nID: ${complaint.complaintId}\nName: ${complaint.fullName}\nEmail: ${complaint.email}\nPhone: ${complaint.phone}\nCategory: ${complaint.category}\nStatus: ${complaint.status}\nDescription: ${complaint.description}\nDate: ${new Date(complaint.date).toLocaleDateString()}\nAssigned Officer: ${complaint.assignedOfficer}`);
        } else {
            showError('Complaint details not found.');
        }
    } catch (error) {
        console.error("View error:", error);
        showError('Error fetching complaint details.');
    }
}*/
// script.js
// View complaint function (fetches the data and now displays the image)
async function viewComplaint(complaintId) {
    try {
        const res = await fetch(`http://localhost:5000/complaints/${complaintId}`);
        const complaint = await res.json();

        if (res.ok && complaint && complaint.complaintId) {
            let details = `Complaint Details:\n\nID: ${complaint.complaintId}\nName: ${complaint.fullName}\nEmail: ${complaint.email}\nPhone: ${complaint.phone}\nCategory: ${complaint.category}\nStatus: ${complaint.status}\nDescription: ${complaint.description}\nDate: ${new Date(complaint.date).toLocaleDateString()}\nAssigned Officer: ${complaint.assignedOfficer}`;

            if (complaint.fileUploadPath) {
                // The browser alert box cannot display an image directly, 
                // so we display the URL and suggest opening it.
                details += `\n\nImage Uploaded: YES\nImage URL: http://localhost:5000${complaint.fileUploadPath}`;
                
                // You should use a better modal/view page, but for the basic alert:
                if (confirm(details + "\n\nDo you want to open the image in a new tab?")) {
                    window.open(`http://localhost:5000${complaint.fileUploadPath}`, '_blank');
                }
            } else {
                 details += `\n\nImage Uploaded: NO`;
                 alert(details);
            }
        } else {
            showError('Complaint details not found.');
        }
    } catch (error) {
        console.error("View error:", error);
        showError('Error fetching complaint details.');
    }
}

// Edit complaint function (updates the data via API)
async function editComplaint(complaintId) {
    try {
        // Fetch current data for better context in prompt
        const res = await fetch(`http://localhost:5000/complaints/${complaintId}`);
        const currentComplaint = await res.json();
        
        if (!res.ok || !currentComplaint || !currentComplaint.complaintId) {
             showError('Could not fetch complaint for editing.');
             return;
        }

        const newStatus = prompt('Enter new status (pending/in-progress/resolved):', currentComplaint.status);
        
        if (newStatus && ['pending', 'in-progress', 'resolved'].includes(newStatus.toLowerCase())) {
            const newAssignedOfficer = prompt('Enter assigned officer:', currentComplaint.assignedOfficer) || currentComplaint.assignedOfficer;
            
            // Send PATCH request to update the complaint
            const updateRes = await fetch(`http://localhost:5000/complaints/${complaintId}`, {
                method: 'PATCH',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ 
                    status: newStatus.toLowerCase(), 
                    assignedOfficer: newAssignedOfficer 
                })
            });

            const result = await updateRes.json();
            if (result.success) {
                loadComplaintsTable(); // Re-load table from server
                showSuccess('Complaint updated successfully!');
            } else {
                showError('Failed to update complaint: ' + (result.message || 'Unknown error.'));
            }
        }
    } catch (error) {
        console.error("Edit error:", error);
        showError('Error communicating with the server to update complaint.');
    }
}

// Delete complaint function (deletes the data via API)
async function deleteComplaint(complaintId) {
    if (confirm('Are you sure you want to delete this complaint?')) {
        try {
            const res = await fetch(`http://localhost:5000/complaints/${complaintId}`, {
                method: 'DELETE'
            });

            const result = await res.json();
            if (result.success) {
                loadComplaintsTable(); // Re-load table from server
                showSuccess('Complaint deleted successfully!');
            } else {
                showError('Failed to delete complaint: ' + (result.message || 'Unknown error.'));
            }
        } catch (error) {
            console.error("Delete error:", error);
            showError('Error communicating with the server to delete complaint.');
        }
    }
}


// --- Complaint Submission & Tracking (User Side) ---

// Final version of the submission handler using the API
/*async function handleComplaintSubmission(e) {
    e.preventDefault();

    const form = document.getElementById("complaintForm");
    const formData = {
        fullName: form.querySelector("#fullName").value,
        email: form.querySelector("#email").value,
        phone: form.querySelector("#phone").value,
        category: form.querySelector("#category").value,
        address: form.querySelector("#address").value,
        description: form.querySelector("#description").value,
        // fileUpload is not handled here as it requires a different POST type (multipart/form-data)
        // For simplicity, we stick to JSON data.
    };

    try {
        const res = await fetch("http://localhost:5000/complaints", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(formData)
        });

        const result = await res.json();
        
        if (result.success) {
            document.getElementById("generatedComplaintId").textContent = result.complaintId;
            showModal();
            form.reset();
        } else {
            showError('Registration failed: ' + result.message);
        }
    } catch (err) {
        showError("Error connecting to server. Please try again.");
    }
}
*/
// script.js

// Final version of the submission handler using the API
async function handleComplaintSubmission(e) {
    e.preventDefault();

    const form = document.getElementById("complaintForm");
    
    // CHANGE: Use FormData object to handle both text and file uploads
    const formData = new FormData(form); 

    try {
        // IMPORTANT: When using FormData, DO NOT set Content-Type header. 
        // The browser sets it automatically with the boundary required for file uploads.
        const res = await fetch("http://localhost:5000/complaints", {
            method: "POST",
            body: formData // Send the raw FormData object
        });

        const result = await res.json();
        
        if (result.success) {
            document.getElementById("generatedComplaintId").textContent = result.complaintId;
            showModal();
            form.reset();
        } else {
            showError('Registration failed: ' + result.message);
        }
    } catch (err) {
        showError("Error connecting to server. Please try again.");
    }
}
// ... (rest of script.js remains the same)
// Track complaint functionality
async function trackComplaint() { 
    const complaintId = document.getElementById('complaintId').value.trim();
    
    if (!complaintId) {
        showError('Please enter a complaint ID');
        return;
    }
    
    const trackResult = document.getElementById('trackResult');
    trackResult.innerHTML = '<p>Loading...</p>';
    trackResult.style.display = 'block';

    try {
        const res = await fetch(`http://localhost:5000/complaints/${complaintId}`);
        const complaint = await res.json();
        
        if (res.ok && complaint && complaint.complaintId) { 
            const status = complaint.status.toLowerCase();
            trackResult.innerHTML = `
                <div class="complaint-status">
                    <h3>Complaint Details</h3>
                    <p><strong>ID:</strong> ${complaint.complaintId}</p>
                    <p><strong>Name:</strong> ${complaint.fullName}</p>
                    <p><strong>Category:</strong> ${complaint.category}</p>
                    <p><strong>Description:</strong> ${complaint.description}</p>
                    <p><strong>Date Submitted:</strong> ${new Date(complaint.date).toLocaleDateString()}</p>
                    <p><strong>Assigned Officer:</strong> ${complaint.assignedOfficer}</p>
                    <div style="margin-top: 1rem; padding: 0.5rem; background: #f0f4f8; border-radius: 5px;">
                        <strong>Status:</strong> <span class="status-badge status-${status.replace('-', '')}">${status.toUpperCase()}</span>
                    </div>
                </div>
            `;
        } else {
            trackResult.innerHTML = `
                <div class="error-message">
                    <i class="fas fa-exclamation-triangle"></i>
                    <p>Complaint not found. Please check the ID and try again.</p>
                </div>
            `;
        }
    } catch (error) {
        console.error("Tracking error:", error);
        trackResult.innerHTML = `
            <div class="error-message">
                <i class="fas fa-exclamation-triangle"></i>
                <p>Error connecting to the server.</p>
            </div>
        `;
    }
}


// --- Other Initializers (Kept for completeness) ---

function initializeNavigation() {
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const targetPage = this.getAttribute('data-page');
            
            // Check if trying to access admin page
            if (targetPage === 'admin') {
                // Check if admin is authenticated
                if (isAdminAuthenticated()) {
                    showPage(targetPage);
                    showAdminDashboard();
                } else {
                    showPage(targetPage);
                    showAdminLogin();
                }
            } else {
                showPage(targetPage);
            }
            
            navLinks.forEach(nav => nav.classList.remove('active'));
            this.classList.add('active');
        });
    });
}

function showPage(pageId) {
    pages.forEach(page => page.classList.remove('active'));
    
    const targetPage = document.getElementById(pageId);
    if (targetPage) {
        targetPage.classList.add('active');
    }
}

function initializeFormValidation() {
    const complaintForm = document.getElementById('complaintForm');
    if (complaintForm) {
        complaintForm.addEventListener('submit', handleComplaintSubmission);
    }
    
    const trackForm = document.getElementById('trackForm');
    if (trackForm) {
        trackForm.addEventListener('submit', function(e) {
            e.preventDefault();
            trackComplaint();
        });
    }
}

function initializeModal() {
    if (closeModalBtn) {
        closeModalBtn.addEventListener('click', closeModal);
    }
    if (successModal) {
        window.addEventListener('click', function(event) {
            if (event.target === successModal) {
                closeModal();
            }
        });
    }
}

function showModal() {
    if (successModal) {
        successModal.style.display = 'block';
    }
}

function closeModal() {
    if (successModal) {
        successModal.style.display = 'none';
    }
}

window.addEventListener('load', function() {
    const hash = window.location.hash.substring(1);
    if (hash) {
        showPage(hash);
        navLinks.forEach(nav => {
            if (nav.getAttribute('data-page') === hash) {
                nav.classList.add('active');
            } else {
                nav.classList.remove('active');
            }
        });
    }
    if (document.getElementById('adminPage') && document.getElementById('adminPage').classList.contains('active')) {
        loadComplaintsTable();
    }
});

// Add event listeners for admin search and filter
document.addEventListener('DOMContentLoaded', function() {
    const adminSearch = document.getElementById('adminSearch');
    const statusFilter = document.getElementById('statusFilter');
    
    if (adminSearch) {
        adminSearch.addEventListener('input', filterComplaints);
    }
    if (statusFilter) {
        statusFilter.addEventListener('change', filterComplaints);
    }
});

// --- Admin Authentication Functions ---

function initializeAdminAuth() {
    const adminLoginForm = document.getElementById('adminLoginForm');
    if (adminLoginForm) {
        adminLoginForm.addEventListener('submit', handleAdminLogin);
    }
    
    // Check if admin is already logged in (from session storage)
    checkAdminSession();
}

function checkAdminSession() {
    const sessionData = sessionStorage.getItem('adminSession');
    if (sessionData) {
        const session = JSON.parse(sessionData);
        if (session.isLoggedIn && session.username) {
            isAdminLoggedIn = true;
            currentAdminUser = session.username;
            showAdminDashboard();
            updateNavigationState();
        }
    }
}

function handleAdminLogin(e) {
    e.preventDefault();
    
    const username = document.getElementById('adminUsername').value.trim();
    const password = document.getElementById('adminPassword').value.trim();
    const errorDiv = document.getElementById('loginError');
    
    // Hide any previous error messages
    if (errorDiv) {
        errorDiv.style.display = 'none';
    }
    
    // Validate credentials
    if (username === ADMIN_CREDENTIALS.username && password === ADMIN_CREDENTIALS.password) {
        // Successful login
        isAdminLoggedIn = true;
        currentAdminUser = username;
        
        // Store session data
        sessionStorage.setItem('adminSession', JSON.stringify({
            isLoggedIn: true,
            username: username,
            loginTime: new Date().toISOString()
        }));
        
        // Show dashboard
        showAdminDashboard();
        
        // Update navigation
        updateNavigationState();
        
        // Clear form
        document.getElementById('adminLoginForm').reset();
        
    } else {
        // Failed login
        isAdminLoggedIn = false;
        currentAdminUser = null;
        
        // Show error message
        if (errorDiv) {
            errorDiv.style.display = 'flex';
        }
        
        // Clear password field
        document.getElementById('adminPassword').value = '';
        
        // Focus on username field
        document.getElementById('adminUsername').focus();
    }
}

function showAdminDashboard() {
    const loginContainer = document.getElementById('adminLogin');
    const dashboardContainer = document.getElementById('adminDashboard');
    const adminUserNameSpan = document.getElementById('adminUserName');
    
    if (loginContainer && dashboardContainer) {
        // Hide login form
        loginContainer.style.display = 'none';
        
        // Show dashboard
        dashboardContainer.style.display = 'block';
        
        // Update welcome message
        if (adminUserNameSpan) {
            adminUserNameSpan.textContent = currentAdminUser;
        }
        
        // Load complaints table
        loadComplaintsTable();
    }
}

function showAdminLogin() {
    const loginContainer = document.getElementById('adminLogin');
    const dashboardContainer = document.getElementById('adminDashboard');
    
    if (loginContainer && dashboardContainer) {
        // Show login form
        loginContainer.style.display = 'block';
        
        // Hide dashboard
        dashboardContainer.style.display = 'none';
        
        // Clear form
        const adminLoginForm = document.getElementById('adminLoginForm');
        if (adminLoginForm) {
            adminLoginForm.reset();
        }
        
        // Hide any error messages
        const errorDiv = document.getElementById('loginError');
        if (errorDiv) {
            errorDiv.style.display = 'none';
        }
        
        // Focus on username field
        const usernameField = document.getElementById('adminUsername');
        if (usernameField) {
            usernameField.focus();
        }
    }
}

function adminLogout() {
    // Clear session data
    sessionStorage.removeItem('adminSession');
    
    // Reset authentication state
    isAdminLoggedIn = false;
    currentAdminUser = null;
    
    // Show login form
    showAdminLogin();
    
    // Navigate to home page
    showPage('home');
    
    // Update navigation
    updateNavigationState();
}

function isAdminAuthenticated() {
    return isAdminLoggedIn;
}

function updateNavigationState() {
    const adminNavLink = document.querySelector('[data-page="admin"]');
    if (adminNavLink) {
        if (isAdminAuthenticated()) {
            adminNavLink.innerHTML = '<i class="fas fa-user-shield"></i> Admin (Logged In)';
            adminNavLink.style.color = '#10b981';
        } else {
            adminNavLink.innerHTML = '<i class="fas fa-shield-alt"></i> Admin';
            adminNavLink.style.color = 'white';
        }
    }
}