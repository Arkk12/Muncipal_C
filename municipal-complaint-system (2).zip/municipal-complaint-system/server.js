const express = require("express");
const { MongoClient, ObjectId } = require("mongodb");
const cors = require("cors");
const multer = require("multer"); 
const path = require("path");     

const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.json());

// --- Multer Configuration for File Uploads ---
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        // Ensure you have an 'uploads/' folder in your project root
        cb(null, 'uploads/'); 
    },
    filename: function (req, file, cb) {
        const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
        cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
    }
});
const upload = multer({ storage: storage });

// Serve the 'uploads' folder statically
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
// ---------------------------------------------


// MongoDB connection
const uri = "mongodb://127.0.0.1:27017";
const client = new MongoClient(uri);

let complaintsCollection;

async function connectDB() {
    try {
        await client.connect();
        const db = client.db("Munciple_Corporation");
        complaintsCollection = db.collection("Register_Complaint");
        console.log("✅ MongoDB Connected to Munciple_Corporation.Register_Complaint");
    } catch (err) {
        console.error("❌ MongoDB connection error:", err);
    }
}
connectDB();


// 1. API to save complaint (Register Complaint page)
app.post("/complaints", upload.single('fileUpload'), async (req, res) => {
    try {
        // Complaint data is in req.body, file details are in req.file
        const complaint = req.body;
        
        // Save the public path to the image in the database
        if (req.file) {
            complaint.fileUploadPath = `/uploads/${req.file.filename}`;
        } else {
            complaint.fileUploadPath = null;
        }

        // Generate custom complaint ID and other defaults
        const year = new Date().getFullYear();
        const count = await complaintsCollection.countDocuments({ complaintId: { $regex: `^MC${year}` } });
        const sequence = String(count + 1).padStart(3, '0');
        complaint.complaintId = `MC${year}${sequence}`;

        complaint.status = complaint.status || "pending";
        complaint.assignedOfficer = complaint.assignedOfficer || "Not Assigned";
        complaint.date = new Date();

        await complaintsCollection.insertOne(complaint);
        res.json({ success: true, message: "Complaint registered successfully!", complaintId: complaint.complaintId });
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});


// 2. API to fetch all complaints (Admin Table)
app.get("/complaints", async (req, res) => {
    try {
        // Fetch and sort by date descending to see newest first
        const complaints = await complaintsCollection.find().sort({ date: -1 }).toArray(); 
        res.json(complaints);
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});


// 3. API to fetch a single complaint by complaintId or _id (Tracking & View)
app.get("/complaints/:id", async (req, res) => {
    try {
        const id = req.params.id;
        let complaint;

        // Try to find by the custom complaintId
        complaint = await complaintsCollection.findOne({ complaintId: id });

        // If not found, try to find by MongoDB's internal _id
        if (!complaint) {
            if (ObjectId.isValid(id)) {
                complaint = await complaintsCollection.findOne({ _id: new ObjectId(id) });
            }
        }

        if (complaint) {
            res.json(complaint);
        } else {
            res.status(404).json({ success: false, message: "Complaint not found" });
        }
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});


// 4. API to update complaint status/officer (Admin Edit)
app.patch("/complaints/:id", async (req, res) => {
    try {
        const id = req.params.id;
        const updateFields = req.body;

        const validUpdates = {};
        if (updateFields.status) validUpdates.status = updateFields.status;
        if (updateFields.assignedOfficer) validUpdates.assignedOfficer = updateFields.assignedOfficer;
        
        if (Object.keys(validUpdates).length === 0) {
            return res.status(400).json({ success: false, message: "No valid fields provided for update." });
        }

        let updateResult;
        
        // Try to update by custom complaintId first
        updateResult = await complaintsCollection.updateOne(
            { complaintId: id },
            { $set: validUpdates }
        );

        // If not found, try to update by MongoDB's internal _id
        if (updateResult.modifiedCount === 0 && ObjectId.isValid(id)) {
             updateResult = await complaintsCollection.updateOne(
                { _id: new ObjectId(id) },
                { $set: validUpdates }
            );
        }

        if (updateResult.modifiedCount > 0) {
            res.json({ success: true, message: "Complaint updated successfully!" });
        } else {
            res.status(404).json({ success: false, message: "Complaint not found or no changes made." });
        }
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});


// 5. API to delete a complaint (Admin Delete)
app.delete("/complaints/:id", async (req, res) => {
    try {
        const id = req.params.id;
        let deleteResult;

        // Try to delete by custom complaintId first
        deleteResult = await complaintsCollection.deleteOne({ complaintId: id });

        // If not deleted, try to delete by MongoDB's internal _id
        if (deleteResult.deletedCount === 0 && ObjectId.isValid(id)) {
            deleteResult = await complaintsCollection.deleteOne({ _id: new ObjectId(id) });
        }

        if (deleteResult.deletedCount > 0) {
            res.json({ success: true, message: "Complaint deleted successfully!" });
        } else {
            res.status(404).json({ success: false, message: "Complaint not found." });
        }
    } catch (err) {
        res.status(500).json({ success: false, message: err.message });
    }
});


app.listen(PORT, () => {
    console.log(`🚀 Server running on http://localhost:${PORT}`);
});